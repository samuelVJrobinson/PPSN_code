#SCRIPT TO CREATE TIF FILES FROM YIELD RASTER DATA. WRITTEN BY SAM ROBINSON SPRING 2023

library(tidyverse)
library(sf)
library(stars)
library(mgcv)
library(parallel)
cl <- makeCluster(12) #Parallel processing cluster. Set this to whatever # of cpus you have (-1)

#Create map theme
mapTheme <- theme_bw()+theme(axis.ticks = element_blank(),axis.text = element_blank())

# library(terra)

setwd("C:\\Users\\samuel.robinson\\Desktop\\Assorted files\\example data for sarah p\\")

filePaths <- list.files(pattern="*\\.csv$") #Get all csv paths

for(path in filePaths){
  fieldName <- strsplit(path,'\\.')[[1]][1] #Get field name from csv path
  
  #Read in data and turn into an sf object
  dat <- read.csv(path) %>%
    mutate(allFilt = tooLarge & vegaFilt & qFilt & bFilt & speedFilt & dSpeedFilt & posFilt) %>% 
    st_as_sf(coords=c('Longitude','Latitude'),remove=FALSE) %>% #Add spatial feature info
    st_set_crs(4326) %>% #Lat-lon format
    st_transform(3401) %>%
    bind_cols(st_coordinates(.)) %>% #Get x,y coords in meters
    mutate(across(c(X,Y),~.x-mean(.x))) %>%  #Center coordinates
    mutate(across(c(Grower:CombineID),factor))
  
  
  mkSmoothMap <- function(d,m,cell=20,isSquare=FALSE){
    st_make_grid(d,square = isSquare,cellsize = cell) %>% 
      st_sf(X=st_coordinates(st_centroid(.))[,1],Y=st_coordinates(st_centroid(.))[,2],geometry=.) %>% 
      mutate(X=X-mean(st_coordinates(d)[,1]),Y=Y-mean(st_coordinates(d)[,2])) %>% 
      bind_cols(sapply(m$xlevels,function(x) rep(x[1],nrow(.)))) %>% 
      mutate(pred=predict(m,newdata=.)) %>% 
      mutate(i = sapply(st_intersects(.,dat),length)) %>% 
      filter(i!=0) %>% ggplot() + geom_sf(aes(fill=pred),col=NA)+
      scale_fill_distiller(palette = 'RdYlGn',direction = 1)+
      mapTheme  
  }
  
  smoothMapList <- vector('list',4)
  yieldMapList <- vector('list',4)
  
  for(f in c('raw','filt')){
    d1 <- dat
    if(f=='filt') d1 <- dat %>% filter(allFilt)
    
    #Fit combine-and-date yield model, with spatial smoother s(X,Y), then refit with autocorrelation term
    #Create figures of smoothers
    m1 <- bam(Yield_tha ~ CombineID*Date_ymd + s(X,Y,k=250),data=d1,cluster=cl) #No rho term
    smoothMapList[[which(sapply(smoothMapList,is.null))[1]]] <- mkSmoothMap(d1,m1)+labs(title=paste0('Smooth ',f,' noAC'))
    ar1 <- acf(resid(m1),type = 'partial')$acf[1,,]
    m1 <- bam(Yield_tha ~ CombineID*Date_ymd + s(X,Y,k=250),data=d1,cluster=cl,rho=ar1) #Refit with rho
    smoothMapList[[which(sapply(smoothMapList,is.null))[1]]] <- (mkSmoothMap(d1,m1)+labs(title=paste0('Smooth ',f,' AC')))
    
    #Back-correct estimated combine effects using AR1 model
    modMat <- model.matrix(~CombineID*Date_ymd,data=d1) #Model matrix
    coefs <- coef(m1)[!grepl('s\\(',names(coef(m1)))] #Get coefficients
    coefs[1] <- 0 #Set first coef (default ID) to zero
    d1$Yield_tha_corr <- d1$Yield_tha - (modMat %*% coefs)[,1] #Corrected yield
    
    #Aggregate data and plot
    grd <- st_as_sf(st_as_stars(st_bbox(d1), dx = 20, dy = 20)) #Create grid (20x20 m cell size)
    agg <- aggregate(select(d1,Yield_tha), grd, FUN = mean) %>% #Aggregate to grid, using median function (or other)
      st_rasterize() #Convert to stars object
    yieldMapList[[which(sapply(yieldMapList,is.null))[1]]] <- ggplot()+ #Create figure
      geom_stars(data = agg,na.action = na.omit)+
      scale_fill_distiller(palette = 'RdYlGn',direction = 1)+
      labs(title=paste0('Yield ',f),fill='Yield\n(t/ha)')+mapTheme  
    write_stars(agg,paste0(fieldName,'_',f,'.tif')) #Write to geoTiff
    
    agg <- aggregate(select(d1,Yield_tha_corr), grd, FUN = median) %>% #Aggregate to grid, using median function (or other)
      st_rasterize() #Convert to stars object
    yieldMapList[[which(sapply(yieldMapList,is.null))[1]]] <- ggplot()+ #Create figure
      geom_stars(data = agg,na.action = na.omit)+
      scale_fill_distiller(palette = 'RdYlGn',direction = 1)+
      labs(title=paste0('Yield ',f,' Adjusted'),fill='Yield\n(t/ha)')+mapTheme
    write_stars(agg,paste0(fieldName,'_',f,'Adjusted.tif')) #Write to geoTiff
  }
  
  p <- do.call(ggpubr::ggarrange,smoothMapList) #Write figures to files
  ggsave(paste0('./',fieldName,'_SmoothMaps.png'),p,scale = 1.5,bg = 'white')
  
  p <- do.call(ggpubr::ggarrange,yieldMapList) #Write figures to files
  ggsave(paste0('./',fieldName,'_YieldMaps.png'),p,scale = 1.5,bg = 'white')
}
  
