#SCRIPT TO CREATE TIF FILES FROM RASTER DATA
# "SCRATCH PAD" FOR TRYING OUT THINGS

library(tidyverse)
library(sf)
library(stars)
# library(terra)

setwd("C:\\Users\\samuel.robinson\\Desktop\\Assorted files\\example data for sarah p\\")

dat <- read.csv("./Alain Section 19_2022.csv") %>%
  filter(tooLarge & vegaFilt & qFilt & bFilt & speedFilt & dSpeedFilt & posFilt) %>%
  st_as_sf(coords=c('Longitude','Latitude'),remove=FALSE) %>% #Add spatial feature info
  st_set_crs(4326) %>% #Lat-lon format
  st_transform(3401) %>%
  bind_cols(st_coordinates(.)) %>% #Get x,y coords in meters
  mutate(across(c(X,Y),~.x-mean(.x))) %>%  #Center coordinates
  mutate(across(c(Grower:CombineID),factor))

grd <- st_as_sf(st_as_stars(st_bbox(dat), dx = 20, dy = 20)) #Create grid (20x20 m cell size)
agg <- aggregate(select(dat,Yield_tha), grd, FUN = median) %>% #Aggregate to grid, using median function (or other)
  st_rasterize() #Convert to stars
plot(agg) #Lots of "striping" from multiple combines
write_stars(agg,'temp.tif') #Write to geoTiff

dat %>% sample_n(size=30000) %>% 
  ggplot()+geom_sf(aes(col=Yield_tha))+
  scale_colour_distiller(palette = 'RdYlGn',direction = 1)

#Combinations of combineID/date - does this relate to "striping"?
dat %>% sample_n(size=30000) %>% mutate(combineDate=paste(CombineID,Date_ymd)) %>% 
  ggplot()+geom_sf(aes(col=combineDate))


#Bunch of striping evident from the different combines. Could fit a model using mgcv to remove combine pattern:
library(mgcv)
library(parallel)
cl <- makeCluster(12) 
m1 <- bam(Yield_tha ~ CombineID*Date_ymd + s(X,Y,k=250),data=dat,cluster=cl,rho=0.78)
summary(m1)

# #Check whether K influences combine/date effects
# nK <- seq(20,300,10)
# coefK <- lapply(nK,function(K){
#   m <- bam(Yield_tha ~ CombineID*Date_ymd + s(X,Y,k=K),data=dat,cluster=cl,rho=0.78,
#            coef=coefficients(m1))
#   getCoefs <- !grepl('s\\(',names(m$coefficients))
#   data.frame(est=m$coefficients[getCoefs],
#              se=sqrt(diag(m$Vc[getCoefs,getCoefs])))
# })
#
## Answer: yes, but not super consistent response
# lapply(coefK,function(x) rownames_to_column(x,'par')) %>% 
#   bind_rows(.id='nk') %>% 
#   mutate(nk=factor(nk,labels=as.character(nK))) %>% 
#   mutate(nk=as.numeric(as.character(nk))) %>% 
#   mutate(upr=est+se*1.96,lwr=est-se*1.96) %>% 
#   ggplot(aes(x=nk,y=est))+geom_pointrange(aes(ymax=upr,ymin=lwr))+geom_line()+
#   facet_wrap(~par,scales='free')
  

#Plot spatial smoother

# gamPredGrid <- function(d,m,x,y){
#   # if(is.null(m)) stop('Model must be specified')
#   
#   st_make_grid(d,square = FALSE,cellsize = 20) %>% 
#     st_sf("{{x}}":=st_coordinates(st_centroid(.))[,1],
#           "{{Y}}":=st_coordinates(st_centroid(.))[,2],
#           geometry=.) %>% 
#     mutate({{X}}:={{X}}-mean(st_coordinates(d)[,1]),{{Y}}:={{Y}}-mean(st_coordinates(d)[,2])) %>% 
#     bind_cols(sapply(m$xlevels,function(x) rep(x[1],nrow(.)))) %>% 
#     mutate(pred=predict(m,newdata=.)) %>% 
#     mutate(i = sapply(st_intersects(.,d),length)) %>% 
#     filter(i!=0)
# }
# 
# gamPredGrid(dat,m1,X,Y)
# debugonce(gamPredGrid)


st_make_grid(dat,square = FALSE,cellsize = 20) %>% 
  st_sf(X=st_coordinates(st_centroid(.))[,1],Y=st_coordinates(st_centroid(.))[,2],geometry=.) %>% 
  mutate(X=X-mean(st_coordinates(dat)[,1]),Y=Y-mean(st_coordinates(dat)[,2])) %>% 
  bind_cols(sapply(m1$xlevels,function(x) rep(x[1],nrow(.)))) %>% 
  mutate(pred=predict(m1,newdata=.)) %>% 
  mutate(i = sapply(st_intersects(.,dat),length)) %>% 
  filter(i!=0) %>% ggplot(g)+geom_sf(aes(fill=pred),col=NA)+
  scale_fill_distiller(palette = 'RdYlGn',direction = 1)

#Correction factor for different combines
modMat <- model.matrix(~CombineID*Date_ymd,data=dat)
coefs <- coef(m1)[!grepl('s\\(',names(coef(m1)))]
coefs[1] <- 0
dat$Yield_tha_corr <- dat$Yield_tha - (modMat %*% coefs)[,1]

p1 <- dat %>% sample_n(size=50000) %>% 
  ggplot()+geom_sf(aes(col=Yield_tha))+
  scale_colour_distiller(palette = 'RdYlGn',direction = 1)

p2 <- dat %>% sample_n(size=50000) %>% 
  ggplot()+geom_sf(aes(col=Yield_tha_corr))+
  scale_colour_distiller(palette = 'RdYlGn',direction = 1)

ggpubr::ggarrange(p1,p2,ncol=2)

# newDat <- dat %>% 
#   select(CombineID,Date_ymd,X,Y) %>%
#   mutate(CombineID="S690 #1 795134 LAJOR",Date_ymd="2022-09-29") %>% 
#   mutate(pred=predict(m1,newdata=.,newdata.guaranteed=TRUE),res=residuals(m1,'response')) %>% 
#   mutate(newdat=pred+res)

# newDat %>% sample_n(size=30000) %>% 
#   ggplot()+geom_sf(aes(col=newdat))

agg2 <- aggregate(select(dat,Yield_tha_corr), grd, FUN = median) %>% #Aggregate to grid, using median function (or other)
  st_rasterize() #Convert to stars

plot(agg2)

#Alternative approach that doesn't use GAM

getCombDiff <- function(i,d,cn=NULL){
  if(is.null(cn)) stop('Column must be named')
  if(length(cn)!=1) stop('Single column only')
  if(class(pull(d,cn))!='factor') stop('Column must be factor')
  retNA <- rep(NA,length(levels(d[,cn]))-1)
  if(length(i)==0) return(retNA)
  d <- d[i,] #Subset dataframe
  #If combine 1 AND at least 1 other present in sampled points
  if(levels(d[,cn])[1] %in% unique(d[,cn]) & length(unique(d[,cn]))>1){
    mY <- tapply(d$Yield_tha,d[,cn],median)
    mY <- mY[2:length(mY)]-mY[1]
    return(mY)
  } else {
    return(retNA)
  }
}


tempDat <- dat %>% #Combine ID and Date factors
  st_drop_geometry() %>% 
  mutate(combDay=factor(paste(CombineID,Date_ymd,sep=':::'))) 

#Intersection list
iList <- st_as_sf(st_as_stars(st_bbox(dat), dx = 30, dy = 30)) %>% 
  st_intersects(.,dat)
# iList <- iList[c(35,69,103,171,409,579)]

cDiff <- sapply(iList,getCombDiff,d=tempDat,cn='combDay') %>% t %>% 
  data.frame %>% setNames(levels(tempDat$combDay)[-1])
  
cDiff %>% pivot_longer(everything()) %>% filter(!is.na(value)) %>% 
  ggplot()+geom_histogram(aes(x=value))+facet_wrap(~name)
  
#Too sparse to calculate for most values. Roughly overlaps modeled intercept values, but way more variability
# Idea: could use between-combine differences to calculate missing values

#Gets differences between factors in an upper triangular matrix
getCombDiff2 <- function(i,d,cn=NULL){
  if(is.null(cn)) stop('Column must be named')
  if(length(cn)!=1) stop('Single column only')
  if(class(pull(d,cn))!='factor') stop('Column must be factor')
  retNA <- matrix(NA,nrow=length(levels(d[,cn]))-1,nrow=length(levels(d[,cn]))-1)
  if(length(i)==0) return(retNA)
  d <- d[i,] #Subset dataframe
  #If at least 2 levels present in sampled points
  if(length(unique(d[,cn]))>1){
    
    
    mY <- tapply(d$Yield_tha,d[,cn],median)
    mY <- mY[2:length(mY)]-mY[1]
    return(mY)
  } else {
    return(retNA)
  }
}


#Example for public posting ------------------
library(tidyverse)
library(sf)
library(stars)

#Make data
N <- 1000
dat <- data.frame(x=runif(N,-10,10),y=runif(N,-10,10),a=rgamma(N,1,1)) %>% 
  st_as_sf(coords=c('x','y')) %>% st_set_crs(4326)

ggplot()+geom_sf(data=dat,aes(col=a)) +
  geom_sf(data=st_make_grid(dat,cellsize = 2),fill=NA)

# st_make_grid(dat,cellsize = 2) %>% st_intersects(.,dat) %>% 
#   sapply(.,function(i) median(dat$a[i])) %>% 
#   matrix(.,ncol=10)
# 
# st_make_grid(dat,cellsize = 2) %>% st_centroid() %>% plot


#2 x 2 grid for rasterization
grd <- st_as_stars(st_bbox(dat), dx = 2, dy = 2)
x <- st_rasterize(dat,grd) #Rasterize
plot(x)
x$a

#Potential solution
grd_vec = st_as_sf(grd)
agg = aggregate(dat, grd_vec, FUN = median)
x = st_rasterize(agg)




